package nave;
public class Nave {
    public static void main(String[] args) {
         navemae obj = new Navinha(); 
        obj.getMsg(); 
    }
    
}
