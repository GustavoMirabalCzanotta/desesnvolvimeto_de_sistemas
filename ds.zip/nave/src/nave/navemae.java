package nave;
public class navemae {
     protected void getMsg() 
    { 
        System.out.println("Energia alta”); 
    } 
}
