package nave;
public class Navinha extends navemae{
     protected void getMsg() 
    { 
        System.out.println("Energia baixa"); 
    } 
}
