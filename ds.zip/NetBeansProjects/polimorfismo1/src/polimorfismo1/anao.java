package polimorfismo1;

public class anao extends personagem{
    @Override 
    void andar(){
    System.out.println("estou andado como bebado");
    }
}
