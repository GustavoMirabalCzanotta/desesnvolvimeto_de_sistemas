package polimorfismo1;

public class Polimorfismo1 {

    public static void main(String[] args) {
        
    }
    
}
