package polimorfismo1;

public class dragao extends personagem{
    
    void andar(){
    System.out.println("estou andado como dragão....");
    
    }
    void falar (){
     System.out.println("estou falando como dragão....");
    }
    
}
