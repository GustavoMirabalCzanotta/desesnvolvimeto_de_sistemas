
package polimorfismo1;


public class fada extends personagem {
    void lancarmagia(){
    System.out.println("lançar magia.....");
    }
    void lancarmagia(int nivel){
        System.out.println("magia cabulosa....");
    
    }
}
