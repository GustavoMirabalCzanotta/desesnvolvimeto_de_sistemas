package carro;

public class modelo_carro {
    String Tipo;
    String Cor;
    String Placa;
    int numPortas;
    
    void setCor(String cor){
        this.Cor = Cor;
    }
    public String getCor(){
          return Cor;   
    }
    void setTipo(String cor){
        this.Tipo = Tipo;
    }
    public String getTipo(){
          return Tipo;   
    }
    void setPlaca(String cor){
        this.Placa = Placa;
    }
    public String getPlaca(){
          return Placa;   
    }
    void setnumPortas(int numPortas){
        this.numPortas = numPortas;
    }
    public int getnumPoratas(){
          return numPortas;
    }  
    
    public modelo_carro(){
     this.Tipo = Tipo;
     this.Cor = Cor;
     this.Placa = Placa;
     this.numPortas = numPortas;
     }
   
 }

