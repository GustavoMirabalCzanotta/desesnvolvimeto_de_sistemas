package carro;
    public class Carro {

    
      
      public static void main(String[] args) {
       
          // 01
          modelo_carro carro = new modelo_carro();
          
          carro.setCor("PRETO");
          carro.setTipo("corrida");
          carro.setPlaca("rtx-123");
          carro.setnumPortas(2);
          
          System.out.println("----CARRO----");
          System.out.println("car " + carro.getCor());
          System.out.println("Tipo: " + carro.getTipo());
          System.out.println("placa: " + carro.getPlaca());
          System.out.println("portas: " + carro.getnumPoratas());
          
          //02
          
          modelo_carro carro_02 = new carro_02 ("Branco","Corrida","rtx-0777",2);
                  
          System.out.println("----CARRO02----");
          System.out.println("cor; " +carro_02);
      }
    
 }
