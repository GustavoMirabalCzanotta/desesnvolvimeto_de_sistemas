
package polimorfismo;

public class dragao {
    void dragao(){
       System.out.println("estou andando com importancia");
 }
}
