
package polimorfismo;


public class Anao extends personagem{
    void Anao(){
       System.out.println("estou andando como bebado");
 }
}
