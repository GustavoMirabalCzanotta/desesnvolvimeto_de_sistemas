
package polimorfismo;

public class personagem {
    String nome;
    
    void andar(){
      System.out.println("estou andando");
    }
}
