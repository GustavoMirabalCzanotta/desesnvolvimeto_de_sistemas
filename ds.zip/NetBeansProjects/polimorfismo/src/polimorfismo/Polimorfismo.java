
package polimorfismo;

public class Polimorfismo {

   
    public static void main(String[] args) {
   
        personagem p1 = new prsonagem();
        
        p1.andar();
    }
    
}
