
package polimorfismo;

public class fada {
    void fada(){
       System.out.println("estou andando com delicadesa");
 }
}
