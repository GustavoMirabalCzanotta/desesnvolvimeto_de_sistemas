
package encapusulamento;


public class pessoa {
    private String nome;
     private int idade;
    private float salario;
    
    void ExibirPessoa(){
        System.out.println("Nome......: " + this.nome);
        System.out.println("Idade.....:" + this.idade);
        System.out.println("Salario: " + this.salario);
    }
    public float getsalario(){
        return salario; 
    }
    public void setsalario(float salario){
       if(salario >= 1100){      
        this.salario = salario;
       }
       else
       {
        System.out.println("O salario esta abixo");
       }
    }
    public String getnome(){
        return nome;
    }
    public void setnome(String nome){
     this.nome = nome;
    }
   
}
