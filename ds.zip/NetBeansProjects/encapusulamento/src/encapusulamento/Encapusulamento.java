
package encapusulamento;

public class Encapusulamento {

    public static void main(String[] args) {

        pessoa p1 = new pessoa();
        
        p1.setsalario(15000);
        
        System.out.println("Salario: ");
    }
    
}
