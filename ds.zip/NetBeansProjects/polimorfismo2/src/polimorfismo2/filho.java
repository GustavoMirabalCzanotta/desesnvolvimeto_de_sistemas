
package polimorfismo2;

public class filho exetends {
    
}
