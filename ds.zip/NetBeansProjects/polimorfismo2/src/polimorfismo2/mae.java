package polimorfismo2;

public class mae {
    void andar(){
       System.out.println("estou nadando.....");
    }
    void cantar(){
       System.out.println("estou cantando Irom Maiden.....");
    }
    void jogarchinelo(){
      System.out.println("estou jogando chinelo.....");
    }
}
