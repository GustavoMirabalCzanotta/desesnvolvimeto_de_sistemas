package jogosdecarta;

public abstract class Carta { 
    int pontuacao;
    int multiplicador;
}

/*
classe carta é abistrata,
ou seja não pode ser estanciada
*/