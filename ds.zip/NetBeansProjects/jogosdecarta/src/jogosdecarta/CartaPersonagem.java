  package jogosdecarta;

import java.util.Random;


public class CartaPersonagem extends Carta {
    int forca;
    int resistencia;
    int inteligencia;
    int fadiga;

    CartaPersonagem ( ){ 

        Random gerador = new Random ();

        forca = gerador.nextInt(100);
        resistencia = gerador.nextInt (100);
        inteligencia = gerador.nextInt(100);
        fadiga = gerador.nextInt(50);
        multiplicador = gerador.nextInt(5);
        pontuacao = (forca + resistencia + inteligencia ) - fadiga;

    }

    void exibirCarta () {
        System.out.println ("-Carta-----------------------------------");
        System.out.println ("Forca........: " + forca);
        System.out.println ("Multiplicador: " + multiplicador);
        System.out.println ("Pontuacao....: " + pontuacao);
        System.out.println ("Resistencia..: " + resistencia);
        System.out.println ("Inteligencia.: " + inteligencia);
        System.out.println ("Fadiga.......: " + fadiga);
        System.out.println("------------------------------------------");


    
    }
}