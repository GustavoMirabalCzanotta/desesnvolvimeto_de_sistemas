package jogosdecarta;


public class Jogador {
    String nome;
    int nr_vitorias;
    int qtd_multiplicador;
    
    CartaPersonagem monte[] = new CartaPersonagem[20];
  
    //metodo construtor
    Jogador(){
        nr_vitorias = 0;
        qtd_multiplicador = 0;
        
        for(int i=0; i<=19; i++){
            CartaPersonagem carta = new CartaPersonagem();
            monte[i] = carta;
        }
        
    }  
    
    void exibirMonte(){
        for(int i=0; i<=19; i++){
            monte[i].exibirCarta();
        }
        
    }  
    
}






/*
vetor armazena variaveis de n objetos,
sem sobre por os objetos
*/