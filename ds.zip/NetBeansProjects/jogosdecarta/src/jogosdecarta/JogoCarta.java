package jogosdecarta;

public class JogoCarta {
  public static void main(String[] args) {
     
       CartaPersonagem carta1 = new CartaPersonagem();
       CartaPersonagem carta2 = new CartaPersonagem();
       
       Jogador paulo = new Jogador();
       Jogador caua = new Jogador();
       
       paulo.exibirMonte();
        

    }
}
/*
CartaPersonagem(classe)
carta1 = objeto
caratapersonagem metodo
*/