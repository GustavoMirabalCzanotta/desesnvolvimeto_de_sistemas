
package estudojavagrafica;


public class EstudoJavaGrafica {

 
    public static void main(String[] args) {
        
        JanelaPrincipal j1 = new JanelaPrincipal();
        
        j1.principal();
        
        
        
    }
    
}
