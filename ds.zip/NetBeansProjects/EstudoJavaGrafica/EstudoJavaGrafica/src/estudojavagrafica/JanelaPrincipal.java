
package estudojavagrafica;


import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class JanelaPrincipal extends JFrame {
    
    void principal(){
        
        try {
            Image iconeTitulo = ImageIO.read(getClass().getResource("logo.jpg"));
            setIconImage(iconeTitulo);
        } catch (IOException ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        setSize(800,600);
        setTitle("Tela principal");
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
}
