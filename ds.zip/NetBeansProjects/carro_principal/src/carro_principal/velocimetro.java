package carro_principal;

import java.util.Random;

public class velocimetro extends Carro_principal{
    int velocidade_max;
    int velocidade_ini;
    int qtd_litros;
    int perda_combustivel;
    
    velocimetro(){
      
     Random gerador = new Random();
         
     velocidade_max = gerador.nextInt(180);
     qtd_litros = gerador.nextInt(5);
     perda_combustivel = (velocidade_max + qtd_litros) - perda_combustivel;  
    }
    
        void exibirvelocimetor(){
         System.out.println("----carro----");
         System.out.println("carro ligado");
         System.out.println("partida: " +velocidade_ini);
         System.out.println("carro acelerando:" +velocidade_max);
         System.out.println("sua gasolina está em: "+qtd_litros+"L");
         System.out.println("Gasolina está em: "+perda_combustivel+"%");
    }     
}