package carro_principal;

public class Carro_principal {

    public static void main(String[] args) {
     
        velocimetro carro = new velocimetro();
        
        carro.exibirvelocimetor();  
    }   
}
