
package interfaces;

public class contacorrente implements Conta{
  
  private double saldo;
	private double taxaOperacao = 0.45;

	
	public void deposita(double valor) {
		this.saldo += valor - taxaOperacao;
	}


	public double getSaldo() {
		return this.saldo;
	}

	
	public void sacar(double valor) {
		this.saldo -= valor + taxaOperacao;
	}

}

