
package interfaces;


public interface estudointeface {
  void depositar(double valor);
	void sacar(double valor);
	double getSaldo();
}
