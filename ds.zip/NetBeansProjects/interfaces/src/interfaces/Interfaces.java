package interfaces;
public class Interfaces {
      public static void main(String[] args) {

		contacorrente cc = new contacorrente();
		cc.deposita(1200.20);
		cc.sacar(300);

		contapoupança cp = new contapoupança();
		cp.deposita(500.50);
		cp.sacar(25);


		geradorextratos gerador = new geradorextratos();
		gerador.geradorconta(cc);
		gerador.geradorConta(cp);
	}

}  
       /*Uma interface é 100% abstrata, 
        ou seja, os seus métodos são definidos como abstract,
        e as variáveis por padrão são sempre constantes . 
        Uma interface é definida através da palavra reservada «interface». 
        Para uma classe implementar uma interface é usada a palavra 
        «implements», 
        descrita na Listagem 8. 
        As classes que forem implementar uma interface terão de adicionar todos 
        os métodos da interface ou se transformar em uma classe abstrata, 
        veja nos exemplos abaixo.*/
   
    

