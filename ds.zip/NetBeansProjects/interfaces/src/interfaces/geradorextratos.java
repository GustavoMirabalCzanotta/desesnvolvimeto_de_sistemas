
package interfaces;

public class geradorextratos {
    
	public void geradorConta(Conta conta){
		System.out.println("Saldo Atual: "+conta.getSaldo());
	}

}
}
