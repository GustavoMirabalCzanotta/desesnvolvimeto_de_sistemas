package teste;

public class Teste {

    public static void main(String[] args) {

 { 
        navemae obj = new navinha(); 
        obj.getMsg(); 
 }
